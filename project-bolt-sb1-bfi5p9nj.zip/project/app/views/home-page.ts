import { EventData, Page, Observable } from '@nativescript/core';

export class HomeViewModel extends Observable {
  private _pickupLocation: string = '';
  private _destination: string = '';
  private _selectedType: string = 'standard';
  private _estimatedFare: number = 0;
  private _isBookingConfirmed: boolean = false;
  private _driverName: string = '';
  private _vehicleDetails: string = '';
  private _estimatedTime: number = 0;
  private _recentRides: Array<any> = [];

  constructor() {
    super();
    this.calculateFare();
    this.loadRecentRides();
  }

  get pickupLocation(): string {
    return this._pickupLocation;
  }

  set pickupLocation(value: string) {
    if (this._pickupLocation !== value) {
      this._pickupLocation = value;
      this.notifyPropertyChange('pickupLocation', value);
      this.calculateFare();
    }
  }

  get destination(): string {
    return this._destination;
  }

  set destination(value: string) {
    if (this._destination !== value) {
      this._destination = value;
      this.notifyPropertyChange('destination', value);
      this.calculateFare();
    }
  }

  get selectedType(): string {
    return this._selectedType;
  }

  set selectedType(value: string) {
    if (this._selectedType !== value) {
      this._selectedType = value;
      this.notifyPropertyChange('selectedType', value);
      this.calculateFare();
    }
  }

  get estimatedFare(): number {
    return this._estimatedFare;
  }

  set estimatedFare(value: number) {
    if (this._estimatedFare !== value) {
      this._estimatedFare = value;
      this.notifyPropertyChange('estimatedFare', value);
    }
  }

  get isBookingConfirmed(): boolean {
    return this._isBookingConfirmed;
  }

  get driverName(): string {
    return this._driverName;
  }

  get vehicleDetails(): string {
    return this._vehicleDetails;
  }

  get estimatedTime(): number {
    return this._estimatedTime;
  }

  get recentRides(): Array<any> {
    return this._recentRides;
  }

  swapLocations() {
    const temp = this.pickupLocation;
    this.pickupLocation = this.destination;
    this.destination = temp;
  }

  selectStandard() {
    this.selectedType = 'standard';
  }

  selectPremium() {
    this.selectedType = 'premium';
  }

  selectLuxury() {
    this.selectedType = 'luxury';
  }

  calculateFare() {
    // Simple fare calculation logic
    let baseFare = 5;
    switch (this.selectedType) {
      case 'premium':
        baseFare = 8;
        break;
      case 'luxury':
        baseFare = 12;
        break;
    }
    
    // Add random distance-based fare
    this.estimatedFare = baseFare + Math.floor(Math.random() * 20);
  }

  bookRide() {
    if (!this.pickupLocation || !this.destination) {
      alert('Please enter pickup and destination locations');
      return;
    }

    // Simulate booking confirmation
    this._isBookingConfirmed = true;
    this._driverName = 'John Smith';
    this._vehicleDetails = 'Toyota Camry - ABC123';
    this._estimatedTime = Math.floor(Math.random() * 10) + 5;
    
    this.notifyPropertyChange('isBookingConfirmed', true);
    this.notifyPropertyChange('driverName', this._driverName);
    this.notifyPropertyChange('vehicleDetails', this._vehicleDetails);
    this.notifyPropertyChange('estimatedTime', this._estimatedTime);

    // Add to recent rides
    this._recentRides.unshift({
      destination: this.destination,
      date: new Date().toLocaleDateString()
    });
    this.notifyPropertyChange('recentRides', this._recentRides);
  }

  private loadRecentRides() {
    // Simulate loading recent rides
    this._recentRides = [
      { destination: 'Airport', date: '2024-01-15' },
      { destination: 'Downtown Mall', date: '2024-01-14' },
      { destination: 'Central Station', date: '2024-01-13' }
    ];
    this.notifyPropertyChange('recentRides', this._recentRides);
  }
}

export function onNavigatingTo(args: EventData) {
  const page = <Page>args.object;
  page.bindingContext = new HomeViewModel();
}